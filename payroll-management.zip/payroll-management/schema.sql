-- ============================================================
-- Employee Payroll Management System - Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS payroll_db;
USE payroll_db;

CREATE TABLE IF NOT EXISTS employees (
    emp_id          INT AUTO_INCREMENT PRIMARY KEY,
    emp_name        VARCHAR(100)   NOT NULL,
    department      VARCHAR(50)    NOT NULL,
    designation     VARCHAR(50)    NOT NULL,
    date_of_joining DATE           NOT NULL,
    basic_salary    DECIMAL(12,2)  NOT NULL,
    hra             DECIMAL(12,2)  DEFAULT 0.00,
    da               DECIMAL(12,2)  DEFAULT 0.00,
    other_allowance DECIMAL(12,2)  DEFAULT 0.00,
    pf_deduction    DECIMAL(12,2)  DEFAULT 0.00,
    tax_deduction   DECIMAL(12,2)  DEFAULT 0.00,
    other_deduction DECIMAL(12,2)  DEFAULT 0.00,
    created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payslips (
    payslip_id      INT AUTO_INCREMENT PRIMARY KEY,
    emp_id          INT NOT NULL,
    pay_month       VARCHAR(20) NOT NULL,
    pay_year        INT NOT NULL,
    gross_salary    DECIMAL(12,2) NOT NULL,
    total_deduction DECIMAL(12,2) NOT NULL,
    net_salary      DECIMAL(12,2) NOT NULL,
    generated_on    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
);
