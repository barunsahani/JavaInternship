# Employee Payroll Management System

A Java console application (Project-2) that calculates and stores employee
salaries in a MySQL database. Built to satisfy the brief:

- Create a payroll management system that calculates and stores employee salaries
- Add new employees, update salary details, generate payslips
- Uses MySQL to store employee and payroll data
- Focus on accurate calculations and secure data handling (PreparedStatements
  used everywhere to prevent SQL injection)

## Project Structure

```
payroll-management/
├── schema.sql                                  # MySQL database & table setup
├── src/com/payroll/
│   ├── PayrollManagementSystem.java            # Main class / console menu
│   ├── model/Employee.java                     # Employee entity + salary calculations
│   ├── dao/PayrollDAO.java                     # All database CRUD + payslip operations
│   ├── service/PayslipGenerator.java           # Formats a printable payslip
│   └── util/DBConnection.java                  # MySQL JDBC connection helper
└── README.md
```

## Prerequisites

1. **JDK 17+** installed
2. **MySQL Server** running locally (or update the connection URL for a remote server)
3. **MySQL Connector/J** (JDBC driver) — download the `.jar` from
   https://dev.mysql.com/downloads/connector/j/

## Setup

### 1. Create the database

```bash
mysql -u root -p < schema.sql
```

This creates `payroll_db` with `employees` and `payslips` tables.

### 2. Configure the connection

Edit `src/com/payroll/util/DBConnection.java` and set your MySQL username/password:

```java
private static final String DB_URL =
        "jdbc:mysql://localhost:3306/payroll_db?useSSL=false&serverTimezone=UTC";
private static final String DB_USER = "root";
private static final String DB_PASSWORD = "your_password";
```

### 3. Compile

Place `mysql-connector-j-<version>.jar` in the project root, then:

```bash
javac -d out $(find src -name "*.java")
```

### 4. Run

**Linux / macOS:**
```bash
java -cp "out:mysql-connector-j-9.1.0.jar" com.payroll.PayrollManagementSystem
```

**Windows:**
```bash
java -cp "out;mysql-connector-j-9.1.0.jar" com.payroll.PayrollManagementSystem
```

## Features

| # | Menu Option            | Description                                                   |
|---|-------------------------|-----------------------------------------------------------------|
| 1 | Add New Employee       | Insert an employee with basic salary, HRA, DA, allowances, deductions |
| 2 | Update Salary Details  | Modify salary components for an existing employee ID          |
| 3 | View All Employees     | List all employees with computed net salary                   |
| 4 | Generate Payslip       | Prints a formatted payslip and stores a record in `payslips`   |
| 5 | Delete Employee        | Remove an employee record                                     |

## Salary Calculation Logic

- **Gross Salary** = Basic Salary + HRA + DA + Other Allowances
- **Total Deductions** = PF + Tax + Other Deductions
- **Net Salary** = Gross Salary − Total Deductions

All calculations are done in `Employee.java` using `BigDecimal` for accurate
financial arithmetic (avoids floating-point rounding errors).

## Secure Data Handling

- All SQL queries use `PreparedStatement` with bound parameters (prevents SQL injection)
- Numeric values use `BigDecimal` (no float/double precision loss)
- Database credentials are isolated in `DBConnection.java` for easy externalization
  (e.g. move to environment variables or a `.properties` file for production use)
