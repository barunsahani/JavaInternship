package com.payroll.model;

import java.math.BigDecimal;
import java.sql.Date;

/**
 * Represents an Employee entity mapped to the `employees` table.
 */
public class Employee {

    private int empId;
    private String empName;
    private String department;
    private String designation;
    private Date dateOfJoining;
    private BigDecimal basicSalary;
    private BigDecimal hra;
    private BigDecimal da;
    private BigDecimal otherAllowance;
    private BigDecimal pfDeduction;
    private BigDecimal taxDeduction;
    private BigDecimal otherDeduction;

    public Employee() {
    }

    public Employee(String empName, String department, String designation, Date dateOfJoining,
                     BigDecimal basicSalary, BigDecimal hra, BigDecimal da, BigDecimal otherAllowance,
                     BigDecimal pfDeduction, BigDecimal taxDeduction, BigDecimal otherDeduction) {
        this.empName = empName;
        this.department = department;
        this.designation = designation;
        this.dateOfJoining = dateOfJoining;
        this.basicSalary = basicSalary;
        this.hra = hra;
        this.da = da;
        this.otherAllowance = otherAllowance;
        this.pfDeduction = pfDeduction;
        this.taxDeduction = taxDeduction;
        this.otherDeduction = otherDeduction;
    }

    // ---------- Getters & Setters ----------

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Date getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(Date dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public BigDecimal getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(BigDecimal basicSalary) {
        this.basicSalary = basicSalary;
    }

    public BigDecimal getHra() {
        return hra;
    }

    public void setHra(BigDecimal hra) {
        this.hra = hra;
    }

    public BigDecimal getDa() {
        return da;
    }

    public void setDa(BigDecimal da) {
        this.da = da;
    }

    public BigDecimal getOtherAllowance() {
        return otherAllowance;
    }

    public void setOtherAllowance(BigDecimal otherAllowance) {
        this.otherAllowance = otherAllowance;
    }

    public BigDecimal getPfDeduction() {
        return pfDeduction;
    }

    public void setPfDeduction(BigDecimal pfDeduction) {
        this.pfDeduction = pfDeduction;
    }

    public BigDecimal getTaxDeduction() {
        return taxDeduction;
    }

    public void setTaxDeduction(BigDecimal taxDeduction) {
        this.taxDeduction = taxDeduction;
    }

    public BigDecimal getOtherDeduction() {
        return otherDeduction;
    }

    public void setOtherDeduction(BigDecimal otherDeduction) {
        this.otherDeduction = otherDeduction;
    }

    // ---------- Derived calculations ----------

    /** Gross salary = basic + hra + da + other allowances */
    public BigDecimal getGrossSalary() {
        return basicSalary.add(hra).add(da).add(otherAllowance);
    }

    /** Total deductions = pf + tax + other deductions */
    public BigDecimal getTotalDeductions() {
        return pfDeduction.add(taxDeduction).add(otherDeduction);
    }

    /** Net salary = gross salary - total deductions */
    public BigDecimal getNetSalary() {
        return getGrossSalary().subtract(getTotalDeductions());
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", empName='" + empName + '\'' +
                ", department='" + department + '\'' +
                ", designation='" + designation + '\'' +
                ", basicSalary=" + basicSalary +
                ", netSalary=" + getNetSalary() +
                '}';
    }
}
