package com.payroll.service;

import com.payroll.model.Employee;

/**
 * Builds a nicely formatted, printable payslip for an employee.
 */
public class PayslipGenerator {

    public static String buildPayslip(Employee emp, String month, int year) {
        StringBuilder sb = new StringBuilder();
        String line = "=".repeat(50);

        sb.append(line).append("\n");
        sb.append(centered("PAYSLIP - " + month.toUpperCase() + " " + year)).append("\n");
        sb.append(line).append("\n");
        sb.append(String.format("%-25s: %s%n", "Employee ID", emp.getEmpId()));
        sb.append(String.format("%-25s: %s%n", "Name", emp.getEmpName()));
        sb.append(String.format("%-25s: %s%n", "Department", emp.getDepartment()));
        sb.append(String.format("%-25s: %s%n", "Designation", emp.getDesignation()));
        sb.append(String.format("%-25s: %s%n", "Date of Joining", emp.getDateOfJoining()));
        sb.append(line).append("\n");
        sb.append(centered("EARNINGS")).append("\n");
        sb.append(String.format("%-25s: %,.2f%n", "Basic Salary", emp.getBasicSalary()));
        sb.append(String.format("%-25s: %,.2f%n", "HRA", emp.getHra()));
        sb.append(String.format("%-25s: %,.2f%n", "DA", emp.getDa()));
        sb.append(String.format("%-25s: %,.2f%n", "Other Allowance", emp.getOtherAllowance()));
        sb.append(String.format("%-25s: %,.2f%n", "GROSS SALARY", emp.getGrossSalary()));
        sb.append(line).append("\n");
        sb.append(centered("DEDUCTIONS")).append("\n");
        sb.append(String.format("%-25s: %,.2f%n", "Provident Fund", emp.getPfDeduction()));
        sb.append(String.format("%-25s: %,.2f%n", "Tax", emp.getTaxDeduction()));
        sb.append(String.format("%-25s: %,.2f%n", "Other Deductions", emp.getOtherDeduction()));
        sb.append(String.format("%-25s: %,.2f%n", "TOTAL DEDUCTIONS", emp.getTotalDeductions()));
        sb.append(line).append("\n");
        sb.append(String.format("%-25s: %,.2f%n", "NET SALARY", emp.getNetSalary()));
        sb.append(line).append("\n");

        return sb.toString();
    }

    private static String centered(String text) {
        int width = 50;
        int padding = Math.max(0, (width - text.length()) / 2);
        return " ".repeat(padding) + text;
    }
}
