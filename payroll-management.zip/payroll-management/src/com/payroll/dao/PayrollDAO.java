package com.payroll.dao;

import com.payroll.model.Employee;
import com.payroll.util.DBConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for all Employee & Payslip related database operations.
 * Handles: adding employees, updating salary details, fetching employees,
 * and generating/storing payslips.
 */
public class PayrollDAO {

    /** Add a new employee record to the database. */
    public int addEmployee(Employee emp) {
        String sql = "INSERT INTO employees " +
                "(emp_name, department, designation, date_of_joining, basic_salary, hra, da, " +
                "other_allowance, pf_deduction, tax_deduction, other_deduction) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, emp.getEmpName());
            ps.setString(2, emp.getDepartment());
            ps.setString(3, emp.getDesignation());
            ps.setDate(4, emp.getDateOfJoining());
            ps.setBigDecimal(5, emp.getBasicSalary());
            ps.setBigDecimal(6, emp.getHra());
            ps.setBigDecimal(7, emp.getDa());
            ps.setBigDecimal(8, emp.getOtherAllowance());
            ps.setBigDecimal(9, emp.getPfDeduction());
            ps.setBigDecimal(10, emp.getTaxDeduction());
            ps.setBigDecimal(11, emp.getOtherDeduction());

            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        return keys.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error adding employee: " + e.getMessage());
        }
        return -1;
    }

    /** Update salary-related fields (basic, hra, da, allowances, deductions) for an employee. */
    public boolean updateSalaryDetails(int empId, BigDecimal basicSalary, BigDecimal hra, BigDecimal da,
                                        BigDecimal otherAllowance, BigDecimal pfDeduction,
                                        BigDecimal taxDeduction, BigDecimal otherDeduction) {
        String sql = "UPDATE employees SET basic_salary = ?, hra = ?, da = ?, other_allowance = ?, " +
                "pf_deduction = ?, tax_deduction = ?, other_deduction = ? WHERE emp_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBigDecimal(1, basicSalary);
            ps.setBigDecimal(2, hra);
            ps.setBigDecimal(3, da);
            ps.setBigDecimal(4, otherAllowance);
            ps.setBigDecimal(5, pfDeduction);
            ps.setBigDecimal(6, taxDeduction);
            ps.setBigDecimal(7, otherDeduction);
            ps.setInt(8, empId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating salary details: " + e.getMessage());
            return false;
        }
    }

    /** Fetch a single employee by ID. */
    public Employee getEmployeeById(int empId) {
        String sql = "SELECT * FROM employees WHERE emp_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, empId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRowToEmployee(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching employee: " + e.getMessage());
        }
        return null;
    }

    /** Fetch all employees. */
    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        String sql = "SELECT * FROM employees ORDER BY emp_id";

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                employees.add(mapRowToEmployee(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching employees: " + e.getMessage());
        }
        return employees;
    }

    /** Delete an employee record. */
    public boolean deleteEmployee(int empId) {
        String sql = "DELETE FROM employees WHERE emp_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, empId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting employee: " + e.getMessage());
            return false;
        }
    }

    /** Generate a payslip for an employee for a given month/year and persist it. */
    public boolean generatePayslip(Employee emp, String month, int year) {
        String sql = "INSERT INTO payslips (emp_id, pay_month, pay_year, gross_salary, total_deduction, net_salary) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, emp.getEmpId());
            ps.setString(2, month);
            ps.setInt(3, year);
            ps.setBigDecimal(4, emp.getGrossSalary());
            ps.setBigDecimal(5, emp.getTotalDeductions());
            ps.setBigDecimal(6, emp.getNetSalary());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error generating payslip: " + e.getMessage());
            return false;
        }
    }

    private Employee mapRowToEmployee(ResultSet rs) throws SQLException {
        Employee emp = new Employee();
        emp.setEmpId(rs.getInt("emp_id"));
        emp.setEmpName(rs.getString("emp_name"));
        emp.setDepartment(rs.getString("department"));
        emp.setDesignation(rs.getString("designation"));
        emp.setDateOfJoining(rs.getDate("date_of_joining"));
        emp.setBasicSalary(rs.getBigDecimal("basic_salary"));
        emp.setHra(rs.getBigDecimal("hra"));
        emp.setDa(rs.getBigDecimal("da"));
        emp.setOtherAllowance(rs.getBigDecimal("other_allowance"));
        emp.setPfDeduction(rs.getBigDecimal("pf_deduction"));
        emp.setTaxDeduction(rs.getBigDecimal("tax_deduction"));
        emp.setOtherDeduction(rs.getBigDecimal("other_deduction"));
        return emp;
    }
}
