package com.payroll;

import com.payroll.dao.PayrollDAO;
import com.payroll.model.Employee;
import com.payroll.service.PayslipGenerator;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/**
 * Employee Payroll Management System
 * ------------------------------------
 * Console application that:
 *  - Adds new employees
 *  - Updates salary details
 *  - Generates payslips
 *  - Stores everything in a MySQL database
 */
public class PayrollManagementSystem {

    private static final PayrollDAO dao = new PayrollDAO();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;

        System.out.println("=====================================");
        System.out.println(" EMPLOYEE PAYROLL MANAGEMENT SYSTEM");
        System.out.println("=====================================");

        while (running) {
            printMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> addEmployee();
                case 2 -> updateSalary();
                case 3 -> viewAllEmployees();
                case 4 -> generatePayslip();
                case 5 -> deleteEmployee();
                case 0 -> {
                    running = false;
                    System.out.println("Exiting... Goodbye!");
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n----------- MAIN MENU -----------");
        System.out.println("1. Add New Employee");
        System.out.println("2. Update Salary Details");
        System.out.println("3. View All Employees");
        System.out.println("4. Generate Payslip");
        System.out.println("5. Delete Employee");
        System.out.println("0. Exit");
        System.out.println("----------------------------------");
    }

    private static void addEmployee() {
        System.out.println("\n-- Add New Employee --");
        String name = readString("Employee Name: ");
        String department = readString("Department: ");
        String designation = readString("Designation: ");
        Date doj = Date.valueOf(LocalDate.now());

        BigDecimal basic = readBigDecimal("Basic Salary: ");
        BigDecimal hra = readBigDecimal("HRA: ");
        BigDecimal da = readBigDecimal("DA: ");
        BigDecimal otherAllowance = readBigDecimal("Other Allowance: ");
        BigDecimal pf = readBigDecimal("PF Deduction: ");
        BigDecimal tax = readBigDecimal("Tax Deduction: ");
        BigDecimal otherDeduction = readBigDecimal("Other Deduction: ");

        Employee emp = new Employee(name, department, designation, doj,
                basic, hra, da, otherAllowance, pf, tax, otherDeduction);

        int id = dao.addEmployee(emp);
        if (id > 0) {
            System.out.println("Employee added successfully with ID: " + id);
        } else {
            System.out.println("Failed to add employee. Check database connection.");
        }
    }

    private static void updateSalary() {
        System.out.println("\n-- Update Salary Details --");
        int empId = readInt("Enter Employee ID: ");
        Employee existing = dao.getEmployeeById(empId);

        if (existing == null) {
            System.out.println("No employee found with ID: " + empId);
            return;
        }

        System.out.println("Current details: " + existing);
        BigDecimal basic = readBigDecimal("New Basic Salary: ");
        BigDecimal hra = readBigDecimal("New HRA: ");
        BigDecimal da = readBigDecimal("New DA: ");
        BigDecimal otherAllowance = readBigDecimal("New Other Allowance: ");
        BigDecimal pf = readBigDecimal("New PF Deduction: ");
        BigDecimal tax = readBigDecimal("New Tax Deduction: ");
        BigDecimal otherDeduction = readBigDecimal("New Other Deduction: ");

        boolean updated = dao.updateSalaryDetails(empId, basic, hra, da, otherAllowance, pf, tax, otherDeduction);
        System.out.println(updated ? "Salary details updated successfully." : "Update failed.");
    }

    private static void viewAllEmployees() {
        System.out.println("\n-- All Employees --");
        List<Employee> employees = dao.getAllEmployees();

        if (employees.isEmpty()) {
            System.out.println("No employees found.");
            return;
        }

        System.out.printf("%-5s %-20s %-15s %-15s %-15s%n", "ID", "Name", "Department", "Designation", "Net Salary");
        System.out.println("-".repeat(75));
        for (Employee emp : employees) {
            System.out.printf("%-5d %-20s %-15s %-15s %,15.2f%n",
                    emp.getEmpId(), emp.getEmpName(), emp.getDepartment(),
                    emp.getDesignation(), emp.getNetSalary());
        }
    }

    private static void generatePayslip() {
        System.out.println("\n-- Generate Payslip --");
        int empId = readInt("Enter Employee ID: ");
        Employee emp = dao.getEmployeeById(empId);

        if (emp == null) {
            System.out.println("No employee found with ID: " + empId);
            return;
        }

        String currentMonth = LocalDate.now().getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        int currentYear = LocalDate.now().getYear();

        String payslip = PayslipGenerator.buildPayslip(emp, currentMonth, currentYear);
        System.out.println(payslip);

        boolean saved = dao.generatePayslip(emp, currentMonth, currentYear);
        System.out.println(saved ? "Payslip saved to database." : "Failed to save payslip record.");
    }

    private static void deleteEmployee() {
        System.out.println("\n-- Delete Employee --");
        int empId = readInt("Enter Employee ID to delete: ");
        boolean deleted = dao.deleteEmployee(empId);
        System.out.println(deleted ? "Employee deleted successfully." : "Employee not found or deletion failed.");
    }

    // ---------- Input helpers ----------

    private static String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static int readInt(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            System.out.print("Please enter a valid number: ");
            scanner.next();
        }
        int value = scanner.nextInt();
        scanner.nextLine();
        return value;
    }

    private static BigDecimal readBigDecimal(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextBigDecimal()) {
            System.out.print("Please enter a valid amount: ");
            scanner.next();
        }
        BigDecimal value = scanner.nextBigDecimal();
        scanner.nextLine();
        return value;
    }
}
